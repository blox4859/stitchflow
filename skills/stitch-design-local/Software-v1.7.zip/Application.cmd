start selector.exe func.txt
